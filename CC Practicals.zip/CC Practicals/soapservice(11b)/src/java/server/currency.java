/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Esha Mankar
 */
@WebService(serviceName = "currency")
public class currency {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "operation")
    public String operation(@WebParam(name = "c") double c) {
        //TODO write your implementation code here:
        return "fahrahheit conversion" +c+ "into celcius" +(1.8*c+32);
    }


    

    
    
}
