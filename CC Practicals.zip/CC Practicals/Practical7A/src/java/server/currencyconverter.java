/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Esha Mankar
 */
@WebService(serviceName = "currencyconverter")
public class currencyconverter {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "intodollar")
    public String intodollar(@WebParam(name = "a") double a) {
        //TODO write your implementation code here:
        return "the indian rupees" +a+ "in dollar is"+(a/83.17);
    }

    

    
}
